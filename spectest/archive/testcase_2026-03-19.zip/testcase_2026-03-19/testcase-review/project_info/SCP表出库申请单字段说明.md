# SCP表出库申请单字段说明


## 出库申请

| 表 | hpoms_scp_so_apply |  | 描述 | 出库申请单-主表 |  |  |  |  |  |  |  |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 字段 | 表字段是否必填Y/N | SCP传参是否必填Y/N | 字段类型 | 字段说明 | 备注 | 接口调用入参Y/N |  |  |  |  |  |
| id | Y |  | varchar(24) | 前缀-SOAP |  |  |  |  |  |  |  |
| apply_order_no | Y |  | varchar(24) | SOAP+13自增ID |  |  |  |  |  |  |  |
| from_order_no | Y | Y | varchar(100) | 订单ID |  | Y |  |  |  |  |  |
| so_type | Y | Y | varchar(20) | 本期固定值：SHOPEC_SO(电商出库) |  | Y |  |  |  |  |  |
| business_type | Y | Y | varchar(20) | 条件值(业务类型)
如果订单为已发货则为SHOPEC_SO_OLD(历史电商出库)
如果订单不为已发货且不为配件单时为SHOPEC_SO(电商出库)
如果订单不为已发货且为配件单时为FITT_SO(配件出库)
如果订单不为已发货且物流分配策略为PICK为SHIP |  | Y |  |  |  |  |  |
| order_status | Y |  | int | 创建出库申请单时默认为1(创建) |  |  |  |  |  |  |  |
| shipment_status | Y |  | int | 创建出库申请单时默认为1(未发货) |  |  |  |  |  |  |  |
| shipment_qty |  |  | int | 创建出库申请单时默认为空 |  |  |  |  |  |  |  |
| warehouse_code |  |  | varchar(20) | 条件值(仓库编码)
如果货主订单采购SKU面单(hpoms_owner_order_purchase_skus_lable)不为空时
为warehouseCode的值 |  | Y |  |  |  |  |  |
| recommend_warehouse_code |  |  | varchar(20) | 条件值(推荐仓库编码)
如果平台为TW平台则为order_skus对应的warehouseId对应的仓库编码，例如BG02 |  | Y |  |  |  |  |  |
| logistics_strategy |  |  | varchar(20) | 条件值(物流策略)
如果订单状态不为已发货且olaLogisticsStrategy不为空且值不等于PICKUP时为olaLogisticsStrategy的值 |  | Y |  |  |  |  |  |
| expected_shipment_time |  |  | date | 条件值(预期发货时间)
如果平台为Temu或者TW时为订单的必须mustShipAt |  | Y |  |  |  |  |  |
| required_delivery_time |  |  | date |  |  | Y |  |  |  |  |  |
| latest_shipping_time |  |  | date |  |  | Y |  |  |  |  |  |
| date_placed |  |  | date | 对应订单下单时间(不做偏移8h的处理) |  | Y |  |  |  |  |  |
| carrier_id |  |  | varchar(30) | 条件值(承运商ID)
如果面单不为空则为面单对应的carrier
如果订单不为已发货且物流分配策略为PICKUP时为PICKUP |  | Y |  |  |  |  |  |
| platform_id |  |  | varchar(25) | 订单对应的平台ID |  | Y |  |  |  |  |  |
| tid |  |  | varchar(60) | 订单的外部订单号 |  | Y |  |  |  |  |  |
| consignee |  |  | varchar(200) | 收货人
firstName +" "+lastName |  | Y |  |  |  |  |  |
| country |  |  | varchar(50) | 国家 |  | Y |  |  |  |  |  |
| state |  |  | varchar(50) | 省份 |  | Y |  |  |  |  |  |
| district |  |  | varchar(50) | 城市 |  | Y |  |  |  |  |  |
| postcode |  |  | varchar(50) | 邮编 |  | Y |  |  |  |  |  |
| address1 |  |  | varchar(255) | 收货地址1
如果平台是Westfield且没有收货地址2则为address1+" "+ORDER ID+" "+
platformReferenceNo |  | Y |  |  |  |  |  |
| address2 |  |  | varchar(255) | 货地址2
如果平台是Westfield且有收货地址2则为address2+" "+ORDER ID+" "+
platformReferenceNo |  | Y |  |  |  |  |  |
| tel1 |  |  | varchar(50) | 条件值(电话1)：
telephone为空时为4000000000
其余条件返回telephone |  | Y |  |  |  |  |  |
| tel2 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| email |  |  | varchar(200) | 邮箱 |  | Y |  |  |  |  |  |
| estimate_freight |  |  | double(16,3) |  |  |  |  |  |  |  |  |
| booking_freight |  |  | double(16,3) |  |  |  |  |  |  |  |  |
| total_weight |  |  | double(16,3) | 申报单明细净重*skuQty四舍五入保留四位之和 |  |  |  |  |  |  |  |
| total_cube |  |  | double(16,3) | 申报单明细体积*skuQty四舍五入保留四位之和 |  |  |  |  |  |  |  |
| total_qty |  |  | int | 货主订单总数量之和 |  | Y |  |  |  |  |  |
| buyer_message |  |  | varchar(500) | 创建申请单时为空 |  | Y |  |  |  |  |  |
| seller_message |  |  | varchar(500) | 创建申请单时为空 |  | Y |  |  |  |  |  |
| carrier_prewrite |  |  | tinyint |  |  |  |  |  |  |  |  |
| carrier_prewrite_at |  |  | date |  |  |  |  |  |  |  |  |
| outbound_at |  |  |  |  |  |  |  |  |  |  |  |
| is_oneself_label |  | Y | tinyint | 条件值(是否自带面单)
如果货主订单采购SKU面单表(hpoms_owner_order_purchase_skus_lable)不为空时为1
为空时是2 |  | Y |  |  |  |  |  |
| remark |  |  | varchar(500) | 条件值(订单备注)：
catch平台:
如果sku包含特殊sku(字典：platform catch_special_sku)时catch-button battery
Ebay平台:
如果isAnc=1为ANC |  | Y |  |  |  |  |  |
| udf01 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udf02 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udf03 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udf04 |  |  | varchar(50) | 条件值(自提 独立波次)
平台是SY、WH且customerRef3=BROERS-PICKUP-VC时为SY-VC |  | Y |  |  |  |  |  |
| udf05 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf06 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf07 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf08 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf09 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udf10 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udfp_biz_dd01 |  |  | varchar(50) | 条件值(历史单出库时间);
如果订单状态为已发货时为
订单的outboundAt，做了偏移8小时 |  | Y |  |  |  |  |  |
| udfp_biz_dd02 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udfp_biz_dd03 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udfp_c01 |  |  | char(1) |  |  | Y |  |  |  |  |  |
| udfp_c02 |  |  | char(2) |  |  | Y |  |  |  |  |  |
| udfp_c03 |  |  | char(3) |  |  | Y |  |  |  |  |  |
| udfp_c04 |  |  | char(4) | 条件值(传Y组独立波次)
如果如果货主订单采购SKU面单不为空且打包状态为1时为N
否则为Y |  | Y |  |  |  |  |  |
| udfp_c05 |  |  | char(5) |  |  | Y |  |  |  |  |  |
| udfp_c06 |  |  | char(6) |  |  | Y |  |  |  |  |  |
| 表 | hpoms_scp_so_apply_details |  | 描述 | 出库申请单-明细表 |  |  |  |  |  |  |  |
| 字段 | 是否必填Y/N | SCP传参是否必填Y/N | 字段类型 | 字段说明 | 备注 |  |  |  |  |  |  |
| id | Y |  | varchar(24) | 前缀-SOAD |  |  |  |  |  |  |  |
| from_order_no | Y | Y | varchar(24) | 订单ID |  |  |  |  |  |  |  |
| from_order_line_no | Y |  | varchar(24) | 货主订单采购SKU ID去掉ORPS前缀 |  | Y |  |  |  |  |  |
| apply_order_id | Y |  | varchar(24) | 申请单ID |  |  |  |  |  |  |  |
| tid |  | Y | varchar(60) | 订单对应的第三方订单ID |  | Y |  |  |  |  |  |
| sku |  | Y | varchar(50) | 货主采购SKU 表-owner_order_purchase_skus-owner_purchase_sku |  | Y |  |  |  |  |  |
| qty_ordered | Y | Y | int | 货主采购SKU 表-owner_order_purchase_skus--quantity |  | Y |  |  |  |  |  |
| qty_shipped |  |  | int | 默认为NULL |  |  |  |  |  |  |  |
| length | Y |  | double(16,3) | 采购SKU-内箱长（innerLength） |  |  |  |  |  |  |  |
| width | Y |  | double(16,3) | 采购SKU-内箱宽（innerWidth） |  |  |  |  |  |  |  |
| height | Y |  | double(16,3) | 采购SKU-内箱高（innerHeight） |  |  |  |  |  |  |  |
| gross_weight | Y |  | double(16,3) | 采购SKU-内箱净重（innerNetWeight） |  |  |  |  |  |  |  |
| net_weight | Y |  | double(16,3) | 采购SKU-外箱净重（outCrossWeight） |  |  |  |  |  |  |  |
| cube | Y |  | double(16,3) | 采购SKU-内箱体积（innerVolume） |  |  |  |  |  |  |  |
| barcode | Y |  | varchar(50) | 采购SKU-条形码（barcode） |  |  |  |  |  |  |  |
| packable | Y |  | tinyint | 采购SKU-是否可打包1是 2否（packable） |  |  |  |  |  |  |  |
| remark |  |  | varchar(500) | 条件值(配件商品备注)：
如果订单基础类型(orderBaseType)为2时
取销售SKU的平台备注(platformRemark) |  | Y |  |  |  |  |  |
| udf01 |  |  | varchar(50) | 条件值(跟踪号)
如果货主订单采购SKU面单不为空时
为tracking的值 |  | Y |  |  |  |  |  |
| udf02 |  |  | varchar(50) | 条件值(承运商)
如果货主订单采购SKU面单不为空时
为carrier的值 |  | Y |  |  |  |  |  |
| udf03 |  |  | varchar(255) | 条件值(lable链接)
如果货主订单采购SKU面单不为空时
为lableUrl的值 |  | Y |  |  |  |  |  |
| udf04 |  |  | varchar(50) |  |  | Y |  |  |  |  |  |
| udf05 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf06 |  |  | varchar(200) |  |  | Y |  |  |  |  |  |
| udf07 |  |  | varchar(500) |  |  | Y |  |  |  |  |  |
| udf08 |  |  | varchar(500) |  |  | Y |  |  |  |  |  |
| lot_att01 |  |  | varchar(20) |  |  | Y |  |  |  |  |  |
| lot_att02 |  |  | varchar(20) |  |  | Y |  |  |  |  |  |
| lot_att03 |  |  | varchar(20) |  |  | Y |  |  |  |  |  |
| lot_att04 |  |  | varchar(100) | 条件值(货主)：
如果仓库货主编码存的时BG，则当前值为BG。
否则为空 |  | Y |  |  |  |  |  |
| lot_att05 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |
| lot_att06 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |
| lot_att07 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |
| lot_att08 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |
| lot_att09 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |
| lot_att10 |  |  | varchar(100) |  |  | Y |  |  |  |  |  |